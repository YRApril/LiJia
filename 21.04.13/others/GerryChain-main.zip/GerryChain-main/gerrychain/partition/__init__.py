from .partition import Partition
from .geographic import GeographicPartition

__all__ = ['Partition', 'GeographicPartition']
