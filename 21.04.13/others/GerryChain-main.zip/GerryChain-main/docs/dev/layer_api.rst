.. _layers:

Writing layer functions
=======================

Proposals
---------

Updaters
--------

Validators
----------

Acceptance functions
--------------------
