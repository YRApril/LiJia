****
Data
****

.. currentmodule:: pymc3.data

.. automodule:: pymc3.data
   :members:
