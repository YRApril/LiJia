*******
Mixture
*******

.. currentmodule:: pymc3.distributions.mixture
.. autosummary::
   Mixture
   NormalMixture
   MixtureSameFamily

.. automodule:: pymc3.distributions.mixture
   :members:
