**********
Timeseries
**********

.. currentmodule:: pymc3.distributions.timeseries
.. autosummary::
    AR1
    AR
    GaussianRandomWalk
    GARCH11
    EulerMaruyama
    MvGaussianRandomWalk
    MvStudentTRandomWalk

.. automodule:: pymc3.distributions.timeseries
   :members:
