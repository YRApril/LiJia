====
ODE
====

This submodule contains tools used to perform inference on ordinary differential equations.

.. currentmodule:: pymc3.ode

.. autosummary::

.. automodule:: pymc3.ode
   :members: DifferentialEquation
