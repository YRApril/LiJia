**************
Mean Functions
**************

.. currentmodule:: pymc3.gp.mean
.. autosummary::

   Zero
   Constant
   Linear

.. automodule:: pymc3.gp.mean
   :members:
