***************
Implementations
***************

.. currentmodule:: pymc3.gp.gp
.. autosummary::
   Latent
   Marginal
   LatentKron
   MarginalKron
   MarginalSparse
   TP

.. automodule:: pymc3.gp.gp
   :members:
