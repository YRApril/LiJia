Gaussian Processes API
----------------------

.. currentmodule:: pymc3.gp.gp

.. toctree::

   gp/implementations
   gp/mean
   gp/cov
