Graphing Models
---------------

.. currentmodule:: pymc3.model_graph
.. automodule:: pymc3.model_graph
   :members:
