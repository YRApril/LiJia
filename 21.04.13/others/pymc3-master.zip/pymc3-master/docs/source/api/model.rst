Model
-----

.. currentmodule:: pymc3.model
.. automodule:: pymc3.model
   :members:
