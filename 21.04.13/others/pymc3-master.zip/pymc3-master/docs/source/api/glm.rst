*************************
Generalized Linear Models
*************************

.. currentmodule:: pymc3.glm.linear

.. automodule:: pymc3.glm.linear
   :members:
