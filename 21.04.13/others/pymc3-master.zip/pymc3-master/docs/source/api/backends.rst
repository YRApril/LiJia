********
Backends
********

.. currentmodule:: pymc3.backends

.. automodule:: pymc3.backends
   :members:

ndarray
^^^^^^^

.. currentmodule:: pymc3.backends.ndarray

.. automodule:: pymc3.backends.ndarray
   :members:

tracetab
^^^^^^^^

.. currentmodule:: pymc3.backends.tracetab

.. automodule:: pymc3.backends.tracetab
   :members:
