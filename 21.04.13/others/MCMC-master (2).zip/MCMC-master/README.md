This is a worksheet for the Local Group Astrostatistics workshop at the
University of Michigan, June 2015.

Run `ipython notebook` and navigate to `MCMC tutorial (worksheet).ipynb` to
get started. The "solutions" are in `MCMC tutorial (solutions).ipynb` if it
comes to that.
