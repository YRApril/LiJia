import numpy as np
import matplotlib.pyplot as pl

import os
import sys

# sys.path.prepend(os.path.abspath(os.path.join(__file__, "..", "..", "..")))
# import emcee


def plot_acor(acorfn):
    pass
