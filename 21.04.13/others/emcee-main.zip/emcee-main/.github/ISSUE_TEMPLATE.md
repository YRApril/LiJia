<!--
Fill in the information below before opening an issue.
If you have a question, please consider emailing the mailing list:
    https://groups.google.com/forum/#!forum/emcee-users
-->

**General information:**

- emcee version:
- platform:
- installation method (pip/conda/source/other?):

**Problem description:**

### Expected behavior:

### Actual behavior:

### What have you tried so far?:

### Minimal example:

<!-- In this section, you should include or link to a code snippet that demonstrates this issue. -->

```python
import emcee

# sample code goes here...
```
