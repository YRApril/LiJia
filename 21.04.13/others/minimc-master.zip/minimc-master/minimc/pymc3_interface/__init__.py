__all__ = ["PyMC3Potential"]

from .potential import PyMC3Potential
