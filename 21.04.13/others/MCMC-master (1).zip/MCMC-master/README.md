##  Markov Chain Monte Carlo    

I implement from scratch, the Metropolis-Hastings algorithm in Python to find parameter distributions for a dummy data example and then of a real world problem.    

I will only use numpy to implement the algorithm, and matplotlib to present the results. Scipy can be used to compute the density functions when needed, but I will also show how to implement them using numpy.
